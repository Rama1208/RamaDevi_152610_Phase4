package com.cg.walletapp.controller;



import java.math.BigDecimal;

import java.util.Collections;
import java.util.Comparator;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.walletapp.beans.Customer;
import com.cg.walletapp.beans.Transaction;
import com.cg.walletapp.service.WalletService;

@RestController
public class WalletController {
@Autowired
private WalletService service;

@RequestMapping(value="/addcustomer",method=RequestMethod.POST)
public void addCustomer(@RequestBody Customer customer) {
	service.addCustomer(customer);
}

@RequestMapping("/showbalance/{mobileno}")
public BigDecimal showBalance(@PathVariable String mobileno) {
	return service.showBalance(mobileno);
}

@RequestMapping("/deposit/{mobileno}/{password}/{amount}")
public String deposit(@PathVariable String mobileno,@PathVariable String password,@PathVariable BigDecimal amount) {
	return service.deposit(mobileno,password,amount);
}

@RequestMapping("/show/{mobileno}")
public Customer showCustomer(@PathVariable String mobileno) {
	return service.showCustomer(mobileno);
}

@RequestMapping("/withdraw/{mobileno}/{password}/{amount}")
public String withdraw(@PathVariable String mobileno,@PathVariable String password,@PathVariable BigDecimal amount) {
	return service.withdraw(mobileno,password,amount);
}
@RequestMapping("/fundtransfer/{targetmobileno}/{sourcemobileno}/{password}/{amount}")
public String fundtrasfer(@PathVariable String targetmobileno,@PathVariable String sourcemobileno,@PathVariable String password,@PathVariable BigDecimal amount) {
	return service.fundtransfer(targetmobileno,sourcemobileno,password,amount);
}
@RequestMapping("/printtransactions/{mobileno}/{password}")
public List<Transaction> printTransactions(@PathVariable String mobileno , @PathVariable String password) {
	List<Transaction> mytransactions=service.printTransactions(mobileno,password);
	
	Collections.sort(mytransactions,  new Comparator<Transaction>() {
		   

		public int compare(Transaction o1, Transaction o2) {
		
			return o1.getDateOfTransaction().compareTo(o2.getDateOfTransaction());
		}
	});
	
	return mytransactions;
}
    
}


