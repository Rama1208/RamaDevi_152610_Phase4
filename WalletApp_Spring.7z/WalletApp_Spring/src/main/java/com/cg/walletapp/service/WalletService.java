package com.cg.walletapp.service;

import java.math.BigDecimal;
import java.util.List;


import com.cg.walletapp.beans.Customer;
import com.cg.walletapp.beans.Transaction;

public interface WalletService {

	public void addCustomer(Customer customer);

	public BigDecimal showBalance(String mobileno);

	public String deposit(String mobileno, String password, BigDecimal amount);

	public Customer showCustomer(String mobileno);

	public String withdraw(String mobileno, String password, BigDecimal amount);

	public String fundtransfer(String targetmobileno, String sourcemobileno, String password, BigDecimal amount);

	public List<Transaction> printTransactions(String mobileno, String password);

}
